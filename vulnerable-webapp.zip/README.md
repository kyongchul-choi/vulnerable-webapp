
보안약점 49개 기준을 테스트해 볼 수 있는 모의 웹 애플리케이션입니다.

요구사항은 다음과 같습니다. 
- Java 17 버전이상 및 Maven 최신버전 설치 및 설정
  
  ![image](https://github.com/user-attachments/assets/74282b39-e839-4ba8-9073-8e9959b52d78)


- IDE (IntelliJ 최신버전)설치 및 다운받은 프로젝트 로딩(File->Open)
  ![image](https://github.com/user-attachments/assets/33232af8-9ff2-4249-b659-206750d80368)


실행방법은 다음과 같습니다.
- VulnerableWebApplication main 함수 실행
![image](https://github.com/user-attachments/assets/a3c7e88c-f651-4e05-ba1a-ce171b58cace)



[참고] main 함수 위치

![image](https://github.com/user-attachments/assets/2f1eaf64-1809-4b2f-b16f-fbd11fe970f6)



접속주소는 다음과 같습니다.

- http://localhost:8080/index.html

![image](https://github.com/user-attachments/assets/dc0e9e33-470f-4066-98a0-7b9a67f1c274)
