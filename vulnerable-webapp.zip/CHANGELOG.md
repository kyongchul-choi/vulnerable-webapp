
- 2025/01/06
파일 업로드 기능에서 웹쉘 업로드후, 명령어 실행이 안되고 404리턴되는 문제해결
추가된 파일 /vulnerabiliities/fileupload/controller/CommandController.java 
