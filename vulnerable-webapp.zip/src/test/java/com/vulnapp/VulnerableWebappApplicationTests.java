package com.vulnapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VulnerableWebappApplicationTests {

	@Test
	void contextLoads() {
	}

}
