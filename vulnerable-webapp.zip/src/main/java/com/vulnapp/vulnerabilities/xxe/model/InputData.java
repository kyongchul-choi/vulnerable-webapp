package com.vulnapp.vulnerabilities.xxe.model;

public class InputData {

    private String xmlContent;

    public String getXmlContent() {
        return xmlContent;
    }

    public void setXmlContent(String xmlContent) {
        this.xmlContent = xmlContent;
    }
}
