package com.vulnapp.vulnerabilities.jwt.model;

public enum UserRole {
    ROLE_USER, ROLE_ADMIN
}