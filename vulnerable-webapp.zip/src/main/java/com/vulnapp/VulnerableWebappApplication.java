package com.vulnapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VulnerableWebappApplication {

	public static void main(String[] args) {
		SpringApplication.run(VulnerableWebappApplication.class, args);
	}

}
